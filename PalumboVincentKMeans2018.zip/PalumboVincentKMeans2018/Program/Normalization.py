# Class name: Normalization
# Class Author: Vincent Palumbo
# Purpose of the class: Normalize data
# Date: 10/08/18
# List of changes with dates: N/A
# Special Notes: N/A

class Normalization:
    # Method Name: Initialize
    # Purpose: Constructor
    # Parameter: Self, topData, bottomData, topNormalize, bottomNormalize
    # Method used: N/A
    # Return Value: N/A
    # Date: 10/08/18
    def __init__(self, topData, bottomData, topNormalize, bottomNormalize):
        # This will set numbers and data to given variables used for normalization
        # The following lines set up the variables that will be used in the next two methods
        self.tData = topData
        self.bData = bottomData
        self.tNorm = topNormalize
        self.bNorm = bottomNormalize
        # dRange = Range for data
        self.dRange = self.tData - self.bData
        # nRange = Range for normalization
        self.nRange = self.tNorm - self.bNorm

    # Method Name: Normalize
    # Purpose: This method will do the actual normalization and return the normalized value
    # Parameter: Self, number
    # Method used: N/A
    # Return Value: normalizedNumber
    # Date: 10/08/18
    def Normalize(self, number):
        # This will simply go through the normalization process
        newNumber = number - self.bData
        temp = newNumber / self.dRange
        preNormalize = self.nRange * temp
        normalizedNumber = self.bNorm + preNormalize
        return normalizedNumber
