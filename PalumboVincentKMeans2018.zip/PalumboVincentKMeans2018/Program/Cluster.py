import random
import math
# Class name: Cluster
# Class Author: Vincent Palumbo
# Purpose of the class: Create Cluster object based on similar mean values
# Date: 10/08/18
# List of changes with dates: none
# Special Notes: none

class Cluster:
    # Method Name: Initialize
    # Purpose: Class Constructor
    # Parameter: self, point, clusters
    # Method used: N/A
    # Return Value: N/A
    # Date: 10/08/18
    def __init__(self, point, clusters):
        # First we will build an array filled with points
        self.point = point
        # Then we will decide on how many clusters their should be
        self.clusters = clusters
        # mean will store the coordinate means for the clusters
        self.mean = []
        # Then we will create a list of the points based on clusters
        self.clusteredPoints = []
        # Finally get information about each clusters states and store it as a string.
        # Leaving it blank initially so it can be filled later
        self.info = ''

    # Method Name: getRandomMean
    # Purpose: Using the random function, this will create a list of random values in a list
    # Parameter: Self
    # Method used: N/A
    # Return Value: N/A
    # Date: 10/08/18
    def getRandomMean(self):
        # The following for loop will create two random numbers based on how many clusters
        # are being used
        for i in range(self.clusters):
            self.mean.append([random.uniform(0.0, 1.0), random.uniform(0.0, 1.0)])

    # Method Name: calcDistance
    # Purpose: This function will calculate Euclidean distance between two points
    # Parameter: self, x2, y2, x1, y1
    # Method used: N/A
    # Return Value: N/A
    # Date: 10/08/18
    def calcDistance(self, x2, y2, x1, y1):
        # Using the Euclidean distance formula, and the math function we will calculate the distance between two points
        return math.sqrt(((y2 - y1) ** 2) + ((x2 - x1) ** 2))

    # Method Name: pointPlacer
    # Purpose: This method will place the points in the hopefully appropriate cluster
    # Parameter: Self
    # Method used: calcDistance()
    # Return Value: N/A
    # Date: 10/08/18
    def pointPlacer(self):
        self.clusteredPoints = []
        # Using a for loop we will take an empty list and put it inside the clustered points list
        for i in range(self.clusters):
            self.clusteredPoints.append([])

        # The next two for loops will go through the point list and set the placements and minimum distance of means
        # The second loop will go through all the found clustered means and find distances

        # This is the loop where we will set the initial placement and distance to zero
        for i in range(len(self.point)):
            placement = 0
            distance = 0

            # This for loop will go through the clusters and calculate distances
            for j in range(self.clusters):
                if (j == 0):
                    distance = self.calcDistance(self.mean[j][0], self.mean[j][1], self.point[i].getXValue(), self.point[i].getYValue())
                newDistance = self.calcDistance(self.mean[j][0], self.mean[j][1], self.point[i].getXValue(), self.point[i].getYValue())

                # This will swap distance and newDistance if distance is greater than newDistance
                # Then update the placement
                if (distance > newDistance):
                    distance = newDistance
                    placement = j

            # The point object is sent to the appropriate cluster point list
            self.clusteredPoints[placement].append(self.point[i])

    # Method Name: calcClustMean
    # Purpose: This method will get the mean of all the points inside a cluster
    # Parameter: Self
    # Method used: N/A
    # Return Value: N/A
    # Date: 10/08/18
    def caclClustMean(self):
        # This for loop will go through however many clusters their are
        for i in range(self.clusters):
            # These will be used to store the mean values for the x and y
            # They will initially be set to zero
            xMean = 0
            yMean = 0

            # This will be used to store the population of the cluster
            clustPop = len(self.clusteredPoints[i])

            # The following if statement will check to see if the found cluster is empty
            # If it is not empty it will iterate through the cluster and get the x/y values
            # Then it will get the means for the x/y values and store them in the appropriate variable
            # Finally, it will update the mean value
            if (not(clustPop == 0)):
                for j in range(clustPop):
                    xMean += self.clusteredPoints[i][j].getXValue()
                    yMean += self.clusteredPoints[i][j].getYValue()
                self.mean[i] = [xMean/clustPop, yMean/clustPop]

    # Method Name: Clustering
    # Purpose: This method will use the previously created methods to build the clusters
    # Parameter: Self
    # Method used: pointPlacer, getRandomMean, calcClustMean
    # Return Value: N/A
    # Date: 10/08/18
    def Clustering(self):
        # First we will use the getRandomMean to create the random points for the clusters
        # Then we will iterate through all 50 points(states) to make sure everyone is where they need to be
        # Finally, we will go through each cluster to get identifying information like cluster number, states, ect.

        self.getRandomMean()
        self.info = ''

        # This is the loop that goes through the 50 points
        for i in range(50):
            self.pointPlacer()
            self.caclClustMean()

        # This is the for loop that gets the identifying information
        for i in range(self.clusters):
            # The \n is just used to move things to a new line for readabilities sake
            self.info += '\nCluster ' + str(i) + ': \n\n'

            # This if statement is used to see if the cluster is empty
            # This should only ever be true when the amount of clusters is close to the top range of 35
            # IF it is true, then it will just display that that particular cluster is empty
            # This is just being used so it doesnt look too broken
            if (len(self.clusteredPoints[i]) == 0):
                self.info += " This Cluster Is Empty \n"
            # Otherwise it will display the found points
            else:
                for j in range(len(self.clusteredPoints[i])):
                    self.info += ' ' + self.clusteredPoints[i][j].getName() + '\n'


    # Method Name: getInfo
    # Purpose: This method will return the contents of "info"
    # Parameter: Self
    # Method used: N/A
    # Return Value: info
    # Date: 10/08/18
    def getInfo(self):
        return self.info
