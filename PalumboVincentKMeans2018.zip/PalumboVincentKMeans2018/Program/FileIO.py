import csv
import os
from tkinter import filedialog
from Program.State import State

# Class name: FileIO
# Class Author: Vincent Palumbo
# Purpose of the class: This class sets the framework for reading a file
# Date: 10/08/18
# List of changes with dates: N/A
# Special Notes: N/A

class FileIO:
    # Method Name: Initialize
    # Purpose: Class Constructor
    # Parameter: Self
    # Method used: N/A
    # Return Value: N/A
    # Date: 10/08/18

    def __init__(self):
        # This class variable will store the name of the users file
        self.fileName = ''
        self.states = []

    # Method Name: openFile
    # Purpose: Opens the file to get some basic info
    # Parameter: Self
    # Method used: N/A
    # Return Value: N/A
    # Date: 10/08/18

    def openFile(self):
        # Gets file path via filedialog
        self.file = filedialog.askopenfilename()
        self.fileName = os.path.basename(self.file)

    # Method Name: readFile()
    # Purpose: Parses through .csv file and formats it
    # Parameter: Self
    # Method used: N/A
    # Return Value: N/A
    # Date: 10/08/18

    def readFile(self):
        with open(self.file) as csvFile:
            csvReader = csv.reader(csvFile, delimiter = ',')
            index = 0

            # For Loop used to run through each row of the file and get data
            # Element 0 will have state name, and Elements 1-4 will have numbered data
            for row in csvReader:
                # State Name
                self.states.append(State(row[0]))
                # Data
                self.states[index].addInfo(float(row[1]))
                self.states[index].addInfo(float(row[2]))
                self.states[index].addInfo(float(row[3]))
                self.states[index].addInfo(float(row[4]))

                # Add one to the incrementer
                index += 1

    # Method Name: getStates()
    # Purpose: This just returns the state name
    # Parameter: Self
    # Method used: N/A
    # Return Value: states
    # Date: 10/08/18

    def getStates(self):
        return self.states




















