from Program.Point import Point
from Program.Normalization import Normalization

# Class name: Calculate
# Class Author: Vincent Palumbo
# Purpose of the class: This class does all the calculations for the clusters
# Date: 10/08/18
# List of changes with dates: N/A
# Special Notes: N/A

class Calculate:
    # Method Name: Initialize
    # Purpose: Constructor
    # Parameter: Self, data
    # Method used: N/A
    # Return Value: N/A
    # Date: 10/08/18

    def __init__(self, data):
        # These lines will store the states, min/max of each category, and the points in a list
        self.data = data
        self.min = []
        self.max = []
        self.points = []

    # Method Name: MinMaxCalc
    # Purpose: This method will calculate the min and max from the data stored in the states
    # Parameter: Self
    # Method used: N/A
    # Return Value: N/A
    # Date: 10/08/18

    def MinMaxCalc(self):
        # These for loops will be used to cycle through each state and collect information
        # It will then set the first state as the minimum and maximum
        # This will be used as a way to compare against other states values to find the true min and max
        for i in range(len(self.data)):
            state = self.data[i].getContainer()
            for j in range(len(state)):
                # This is where we set the state to be min and max
                if (i < 1):
                    self.min.append(state[j])
                    self.max.append(state[j])
                else:
                    # This is where we compare every other state to each other to find
                    # the true min and max values
                    if (state[j] < self.min[j]):
                        self.min[j] = state[j]
                    elif (state[j] > self.max[j]):
                        self.max[j] = state[j]

    # Method Name: normalizeData
    # Purpose: This method will normalize the values
    # Parameter: Self
    # Method used: N/A
    # Return Value: N/A
    # Date: 10/08/18

    def normalizeData(self):
        # First we will set the population to the size of the collected data
        # Then find the number of groups
        population = len(self.data)
        for i in range(population):
            state = self.data[i].getContainer()
            for j in range(len(state)):
                normalize = Normalization(self.max[j], self.min[j], 1, 0)
                self.data[i].setInfo(j, normalize.Normalize(state[j]))

    # Method Name: point
    # Purpose: Get 2D coordinates
    # Parameter: Self
    # Method used: N/A
    # Return Value: N/A
    # Date: 10/08/18

    def point(self):
        # Set population to size of data
        population = len(self.data)
        # Get number of groups inside the states
        for i in range(population):
            # Set total to 0 so it can be added to later in the loop
            total = 0
            # Get the list from before
            state = self.data[i].getContainer()
            for j in range(len(state)):
                if(not(j == 3)):
                    total += state[j]
            # Attach the points
            self.points.append(Point(self.data[i].getName(), float(state[2]), float(total / 3)))

    # Method Name: pointList
    # Purpose: This method will return a list of the points
    # Parameter: Self
    # Method used: N/A
    # Return Value: points
    # Date: 10/08/18
    def pointList(self):
        return self.points

    # Method Name: InitializeCalculations
    # Purpose: This method will call the calculation methods created above
    # Parameter: Self
    # Method used: MinMaxCalc, normalizeData, point
    # Return Value: N/A
    # Date: 10/08/18
    def InitializeCalculations(self):
        self.MinMaxCalc()
        self.normalizeData()
        self.point()
