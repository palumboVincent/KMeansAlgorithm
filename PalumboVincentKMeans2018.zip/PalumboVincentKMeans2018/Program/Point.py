# Class name: Point
# Class Author: Vincent Palumbo
# Purpose of the class: Create the Point object to store state name and coordinates
# Date: 10/08/18
# List of changes with dates: N/A
# Special Notes: N/A

class Point:
    # Method Name: Initialize
    # Purpose: Class Constructor
    # Parameter: self, name, x, y
    # Method used: N/A
    # Return Value: N/A
    # Date: 10/08/18
    def __init__(self, name, x, y):
        # Just setting some basic values
        self.name = name
        self.x = x
        self.y = y

    # The following methods will be used to pull names, x/y values, and coordinates for other functions

    # Method Name: getName
    # Purpose: Return the name of a variable
    # Parameter: Self
    # Method used: N/A
    # Return Value: name
    # Date: 10/08/18
    def getName(self):

        return self.name

    # Method Name: getXValue
    # Purpose: Return the value of X
    # Parameter: Self
    # Method used: N/A
    # Return Value: The value of X
    # Date: 10/08/18
    def getXValue(self):
        return self.x

    # Method Name: getYValue
    # Purpose: Return the value of Y
    # Parameter: Self
    # Method used: N/A
    # Return Value: The value of Y
    # Date: 10/08/18
    def getYValue(self):
        return self.y

    # Method Name: getCoordinates
    # Purpose: Return the value of some coordinates
    # Parameter: Self
    # Method used: N/A
    # Return Value: A string with the coordinates in them
    # Date: 10/08/18
    def getCoordinates(self):
        return str(self.name) + ': (' + str(self.x) + ', ' + str(self.y) + ')'
