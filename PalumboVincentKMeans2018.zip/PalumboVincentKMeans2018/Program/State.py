# Class name: State
# Class Author: Vincent Palumbo
# Purpose of the class: Creates framework for states. Holds name and attributes
# Date: 10/08/18
# List of changes with dates: N/A
# Special Notes: N/A

class State:
    # Method Name: Initialize
    # Purpose: Class Constructor
    # Parameter: self, name
    # Method used: N/A
    # Return Value: N/A
    # Date: 10/08/18
    def __init__(self, name):
        self.name = name
        self.container = []

    # Method Name: getContainer
    # Purpose: This method will return the list of values
    # Parameter: Self
    # Method used: N/A
    # Return Value: N/A
    # Date: 10/08/18
    def getContainer(self):
        return self.container

    # Method Name: setName
    # Purpose: This method will set the name of a data point
    # Parameter: Self, name
    # Method used: N/A
    # Return Value: N/A
    # Date: 10/08/18
    def setName(self, name):
        self.name = name

    # Method Name: getName
    # Purpose: This method will return the name of a state
    # Parameter: Self, name
    # Method used: N/A
    # Return Value: N/A
    # Date: 10/08/18
    def getName(self):
        return self.name

    # Method Name: setInfo
    # Purpose: This method will set the numerical value to the selected index
    # Parameter: Self, index, value
    # Method used: N/A
    # Return Value: N/A
    # Date: 10/08/18
    def setInfo(self, index, value):
        self.container[index] = value

    # Method Name: addInfo
    # Purpose: This method will append the numerical value to the selected list
    # Parameter: Self, value
    # Method used: N/A
    # Return Value: N/A
    # Date: 10/08/18
    def addInfo(self, value):
        self.container.append(value)
