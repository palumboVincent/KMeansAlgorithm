import tkinter as tk
import tkinter.scrolledtext as tkst
from Program.Calculate import Calculate
from Program.Cluster import Cluster
from Program.FileIO import FileIO

# Class Name: GUI
# Class Author: Vincent Palumbo
# Purpose: This class will create the GUI for the program
# Date: 10/08/18
# List of changes with dates: N/A
# Special Notes: N/A

class GUI:

    # Method Name: btnEnter()
    # Purpose: Event handler for the "Enter Button". When pressed, the program will execute.
    # Parameter: The event.
    # Method used: N/A
    # Return Value: N/A
    # Date: 10/08/18

    def __btnEnterEvent(self, event):
        # This will be used to display information above the text box for the user
        self.lblStatus.config(text = '')
        if self.lblFile.cget('text') != 'No File Was Uploaded':
            self.editArea.delete('1.0', tk.END)

            if (self.isInteger(self.txtUserInput.get())):
                self.cluster = Cluster(self.calculate.pointList(), int(float(self.txtUserInput.get())))
                # Creates clusters based on user input.
                self.cluster.Clustering()
                # Posts resulting clusters in the list box area
                # TODO: add functionality for graphs via numpy/matplotlib or something
                self.editArea.insert(tk.INSERT, self.cluster.getInfo())
        else:
            self.lblStatus.config(text = 'Please only load .csv files')


    # Method Name: btnUploadEvent()
    # Purpose: Event handler for the "Upload Button". When pressed, the program will upload the users file.
    # Parameter: The event.
    # Method used: N/A
    # Return Value: N/A
    # Date: 10/08/18

    def __btnUploadEvent(self, event):
        self.data = FileIO()
        # Setting initial calculations/clusters to zero. Change as things update
        self.cluster = 0
        self.calculate = 0

        # Inside this try catch, the program will use methods from the FileIO class to read,
        # and open the users file.
        try:
            self.data.openFile()
            self.data.readFile()
            self.lblFile.config(text = self.data.fileName)
        except:
            self.lblFile.config(text = 'No File Was Uploaded')

        self.calculate = Calculate(self.data.getStates())
        self.calculate.InitializeCalculations()

        # Clearing the lblStatus label
        self.lblStatus.config(text = '')


    # Method Name: IS_INT()
    # Purpose: This method will check to see if the text the user inputted is an integer. If not, lblStatus will display
    ########## an appropriate error message.
    # Parameter: self, num.
    # Method used: N/A
    # Return Value: Boolean value is returned
    # Date: 10/08/18

    def isInteger(self, num):
        try:
            if float(num).is_integer():
                # This will check that the inputted integer is within a reasonable range
                if not(float(num) > 0 and float(num) < 30):
                    # Display an appropriate error message
                    self.lblStatus.config(text = 'Please enter a K value between 0 and 30')
                    return False
                return True
            else:
                # Tell the user to only enter an integer
                self.lblStatus.config(text = 'Please only enter an integer')
                return False
        except:
            return False


    # Method Name: __init__()
    # Purpose: Class constructor
    # Parameter: self
    # Method used: btnEnter(), btnUpLoad()
    # Return Value: N/A
    # Date: 10/08/18

    def __init__(self):
        # These class variables will affect the actual GUI window
        self.GUI = tk.Tk()
        # This will set the actual main window text
        self.GUI.title('Palumbo K-Means Clustering Project')
        # These next two lines will set the size of the GUI
        self.GUI.geometry('285x875')
        self.GUI.minsize(100, 875)

        # This will create the upload button object, then place it on the GUI
        btnUpload = tk.Button(self.GUI, width = 15, height = 2, text = 'Upload Here')
        btnUpload.place(x = 10, y = 800)
        # Initialize the btnUpload event
        btnUpload.bind('<ButtonRelease-1>', self.__btnUploadEvent)

        # This will create the enter button object, then place it on the GUI
        btnEnter = tk.Button(self.GUI, width = 15, height = 2, text = 'Cluster Data')
        btnEnter.place(x = 155, y = 800)
        # Initialize the btnEnter event
        btnEnter.bind('<ButtonRelease-1>', self.__btnEnterEvent)

        # This creates the label objects
        self.lblFile = tk.Label(self.GUI, height = 2, text = 'No File!')
        self.lblFile.place(x = 50, y = 22)

        self.lblStatus = tk.Label(self.GUI, height = 2, text = '')
        self.lblStatus.place(x = 25, y = 710)

        # This creates the textbox object
        self.txtUserInput = tk.Entry(self.GUI, width = 43)
        self.txtUserInput.place(x = 10, y = 750)

        # Creates the list box style area where clusters will be displayed
        self.editArea = tkst.ScrolledText(master = self.GUI, wrap = tk.WORD, width = 30, height = 40)
        self.editArea.pack(padx = 10, pady = 10, fill = tk.NONE, expand = False)
        self.editArea.place(x = 10, y = 50)


    # Method Name: Start()
    # Purpose: This will start the GUI/Project
    # Parameter: Self
    # Method used: N/A
    # Return Value: N/A
    # Date: 10/08/18

    def start(self):
        self.GUI.mainloop()


