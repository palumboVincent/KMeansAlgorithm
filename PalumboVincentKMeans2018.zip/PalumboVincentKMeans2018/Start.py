from Program.GUI import GUI
# Class name: Start
# Class Author:
# Purpose of the class: Starts Program
# Date: 10/08/18
# List of changes with dates: N/A
# Special Notes: N/A


program = GUI()
program.start()
